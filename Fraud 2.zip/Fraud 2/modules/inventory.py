from utils.file_reader import read_file
from modules.gst_loader import load_gst_vendor
from utils.benford import benford_test
from utils.column_mapper import find_column
import pandas as pd

def inventory_check(file):
    df = read_file(file)
    issues = []

    try:
        gst_map = load_gst_vendor()
    except Exception as e:
        return {"issues": [{"row": "System", "type": f"GST Loader Error: {str(e)}"}], 
                "count": 1, "risk": "HIGH", "stats": {"valid": 0, "invalid": 0}}

    # Smart column detection
    gst_col = find_column(df, ["gstin", "gst", "gstno"])
    vendor_col = find_column(df, ["vendor", "vendorname", "supplier", "name"])
    price_col = find_column(df, ["unitprice", "price", "amount", "rate", "value"])

    if not all([gst_col, vendor_col, price_col]):
        return {"issues": [{"row": "All", "type": "Missing Required Columns (GST, Vendor, or Price)"}], "count": 1, "risk": "HIGH", "stats": {"valid":0,"invalid":0}}

    # Normalize data for comparison
    df[gst_col] = df[gst_col].astype(str).str.upper().str.strip()
    df[vendor_col] = df[vendor_col].astype(str).str.upper().str.strip()

    valid, invalid = 0, 0

    for i, row in df.iterrows():
        gst = row[gst_col]
        vendor = row[vendor_col]

        if gst not in gst_map:
            invalid += 1
            issues.append({
                "module": "Inventory",
                "row": i+2,
                "pattern": "FAKE_GST",
                "type": "FAKE_GST",
                "risk": "HIGH",
                "vendor_name": vendor,
                "gst_number": gst,
                "details": f"GST Validation Failed: {gst} unregisterd gst no"
            })
        elif gst_map[gst] != vendor:
            invalid += 1
            master_vendor = gst_map[gst]
            issues.append({
                "module": "Inventory",
                "row": i+2,
                "pattern": "VENDOR_MISMATCH",
                "type": "VENDOR_MISMATCH",
                "risk": "HIGH",
                "details": f"Vendor Mismatch: Invoice '{vendor}' vs Master '{master_vendor}' for GST {gst}",
                "vendor_name_invoice": vendor,
                "vendor_name_master": master_vendor,
                "gst_number": gst
            })
        else:
            valid += 1
    count = len(issues)
    risk = "LOW" if count == 0 else "MEDIUM" if count <= 10 else "HIGH"

    return {"issues": issues, "count": count, "risk": risk,
            "stats": {"valid": valid, "invalid": invalid}}