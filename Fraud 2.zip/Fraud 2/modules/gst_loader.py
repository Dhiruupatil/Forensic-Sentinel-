import pandas as pd

def load_gst_vendor():
    df = pd.read_excel("data/GST AND VENDER.xlsx")
    df.columns = [c.strip().lower() for c in df.columns]

    gst_col = None
    vendor_col = None

    for col in df.columns:
        if "gst" in col:
            gst_col = col
        if "vendor" in col or "name" in col:
            vendor_col = col

    if not gst_col or not vendor_col:
        raise Exception("GST or Vendor column not found in Excel file")

    gst_map = {}
    for _, row in df.iterrows():
        gst = str(row[gst_col]).strip().upper()
        vendor = str(row[vendor_col]).strip().upper()
        gst_map[gst] = vendor
    return gst_map