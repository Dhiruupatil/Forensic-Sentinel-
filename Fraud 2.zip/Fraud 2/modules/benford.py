import pandas as pd

def benford_test(series):
    # Convert to string, remove decimals to handle floats correctly
    series = series.astype(str).str.replace(".", "", regex=False)
    # Extract first digit
    first_digits = series.str[0]
    # Filter for valid digits (1-9)
    first_digits = first_digits[first_digits.str.isnumeric() & (first_digits != "0")]
    
    if len(first_digits) == 0:
        return False

    dist = first_digits.value_counts(normalize=True)
    # Check if digit '1' deviates significantly from ~30.1% (using 0.1 threshold)
    return abs(dist.get("1", 0) - 0.301) > 0.1