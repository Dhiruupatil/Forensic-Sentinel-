import pandas as pd
from rapidfuzz import fuzz, distance
import re
from datetime import datetime
from utils.benford import calculate_benford_deviation

def payroll_check(file):
    file.seek(0)
    if file.filename.lower().endswith(".csv"):
        df = pd.read_csv(file)
    else:
        df = pd.read_excel(file)

    # 1. Column Detection (Case Insensitive, No Normalization)
    def get_col(keywords):
        for col in df.columns:
            col_upper = str(col).upper()
            for k in keywords:
                if k in col_upper:
                    return col
        return None

    # 2. Detect Name Column Automatically
    name_col = get_col(["EMPLOYEE_NAME", "NAME", "STAFF", "EMPLOYEE"])
    
    if not name_col:
        return {"issues": [], "count": 0, "risk": "LOW"}

    # Detect Employee ID Column
    id_col = get_col(["EMPLOYEE_ID", "EMP_ID", "EMPID", "ID"])

    # Detect other columns
    bank_col = get_col(["BANK", "ACCOUNT", "ACCT", "IFSC", "IBAN"])
    doj_col = get_col(["JOIN_DATE", "DOJ", "APPOINTMENT", "JOIN"])
    
    # Worked Days (Avoid confusion with Join Date)
    worked_col = None
    for col in df.columns:
        c_up = str(col).upper()
        if any(x in c_up for x in ["WORKED_DAYS", "WORK", "PRESENT", "PAYABLE", "ATTENDANCE", "DAYS"]) and "JOIN" not in c_up:
            worked_col = col
            break
    
    gross_col = get_col(["GROSS", "SALARY", "CTC", "TOTAL", "FIXED"])
    net_col = get_col(["NET", "PAID", "PAYOUT", "AMOUNT"])
    salary_col = get_col(["SALARY", "GROSS", "CTC", "TOTAL", "FIXED", "NET", "PAID", "PAYOUT", "AMOUNT"])
    
    payment_col = get_col(["PAYMENT", "PAY_DATE"])
    bonus_col = get_col(["BONUS"])
    incentive_col = get_col(["INCENTIVE"])

    print(f"DEBUG: Detected Columns -> Name: {name_col}, ID: {id_col}, Bank: {bank_col}, DOJ: {doj_col}, Worked: {worked_col}, Salary: {salary_col}, Payment: {payment_col}")

    # Date conversion
    if doj_col:
        df[doj_col] = pd.to_datetime(df[doj_col], errors="coerce")

    # 3. Preprocess Records
    records = []
    for idx, val in df[name_col].dropna().astype(str).items():
        raw = val.strip()
        if not raw or raw.lower() == "nan":
            continue
            
        # Clean: lowercase, keep only alphanumeric + space
        clean = re.sub(r"[^a-z0-9\s]", "", raw.lower()).strip()
        # Normalize whitespace
        clean = re.sub(r"\s+", " ", clean)
        
        if len(clean) < 2:
            continue
            
        parts = clean.split()
        first = parts[0] if parts else ""
        last = parts[-1] if len(parts) > 1 else ""
        
        records.append({
            "id": idx,
            "raw": raw,
            "clean": clean,
            "first": first,
            "last": last
        })

    issues = []
    n = len(records)
    suspicious_amounts = []

    # ---------------------------------------------------------
    # 🔴 1️⃣ DUPLICATE BANK ACCOUNT DETECTION
    # ---------------------------------------------------------
    if bank_col:
        # Filter valid banks (ignore nan, empty, '0', 'nan')
        valid_banks = df[df[bank_col].notna()].copy()
        valid_banks[bank_col] = valid_banks[bank_col].astype(str).str.strip()
        valid_banks = valid_banks[~valid_banks[bank_col].str.lower().isin(["nan", "none", "0", ""])]

        # Group by bank account
        bank_groups = valid_banks.groupby(bank_col)[name_col].apply(list)
        
        # Filter for duplicates
        duplicates = bank_groups[bank_groups.apply(len) > 1]

        for bank_acc, employees in duplicates.items():
            issues.append({
                "module": "Payroll",
                "pattern": "DUPLICATE_BANK_ACCOUNT",
                "type": "DUPLICATE_BANK_ACCOUNT", # For Dashboard
                "issue_type": "DUPLICATE_BANK_ACCOUNT",
                "risk": "HIGH",
                "bank_account": bank_acc,
                "employee_count": len(employees),
                "employees": employees,
                "details": f"Bank Account {bank_acc} shared by {len(employees)} employees"
            })

    # ---------------------------------------------------------
    # 👻 2️⃣ GHOST EMPLOYEE DETECTION
    # ---------------------------------------------------------
    if doj_col and payment_col:
        # Step 1: Convert dates
        df[doj_col] = pd.to_datetime(df[doj_col], errors="coerce", dayfirst=True)
        df[payment_col] = pd.to_datetime(df[payment_col], errors="coerce", dayfirst=True)
        
        # Ensure numeric
        if net_col: df[net_col] = pd.to_numeric(df[net_col], errors="coerce").fillna(0)
        if bonus_col: df[bonus_col] = pd.to_numeric(df[bonus_col], errors="coerce").fillna(0)
        if incentive_col: df[incentive_col] = pd.to_numeric(df[incentive_col], errors="coerce").fillna(0)

        for idx, row in df.iterrows():
            doj = row[doj_col]
            pay_date = row[payment_col]
            
            if pd.isna(doj) or pd.isna(pay_date):
                continue
            
            days_worked = (pay_date - doj).days
            
            if days_worked < 0:
                continue
            
            net_pay = row[net_col] if net_col else 0
            
            # Detection Rules: days_worked <= 20 AND Net Pay > 0
            if days_worked <= 20 and net_pay > 0:
                emp_name = str(row[name_col]) if name_col else "Unknown"
                emp_id = str(row[id_col]) if id_col else "UNKNOWN"
                bank_acc = str(row[bank_col]) if bank_col else "UNKNOWN"
                
                # Risk Classification
                risk = "MEDIUM"
                if days_worked <= 10:
                    risk = "HIGH"
                
                # Bonus/Incentive Abuse Rule
                bonus = row[bonus_col] if bonus_col else 0
                incentive = row[incentive_col] if incentive_col else 0
                
                if days_worked <= 20 and (bonus > 0 or incentive > 0):
                    risk = "HIGH"
                
                # Collect suspicious amounts for Benford Analysis
                if net_pay > 0: suspicious_amounts.append(net_pay)
                if bonus > 0: suspicious_amounts.append(bonus)
                if incentive > 0: suspicious_amounts.append(incentive)
                if salary_col:
                    try:
                        val = float(row[salary_col])
                        if val > 0: suspicious_amounts.append(val)
                    except (ValueError, TypeError): pass

                # Confidence Score Calculation
                confidence = 70
                if days_worked <= 7: confidence += 15
                if bonus > 0: confidence += 10
                if incentive > 0: confidence += 10
                
                confidence = min(100, confidence)
                
                details = f"Employee ID {emp_id} joined {days_worked} days before payment but received salary"
                if bonus > 0 or incentive > 0:
                    details += " + Bonus/Incentive Abuse"

                issues.append({
                    "module": "Payroll",
                    "pattern": "GHOST_EMPLOYEE",
                    "type": "GHOST_EMPLOYEE", # For Dashboard
                    "issue_type": "GHOST_EMPLOYEE",
                    "risk": "HIGH",
                    "employee_name": emp_name,
                    "employee_id": emp_id,
                    "bank_account": bank_acc,
                    "salary": row[salary_col] if salary_col else net_pay,
                    "days_worked": int(days_worked),
                    "net_pay": float(net_pay),
                    "bonus": float(bonus),
                    "incentive": float(incentive),
                    "confidence": confidence,
                    "details": details
                })

    # ---------------------------------------------------------
    # 🔍 3️⃣ FUZZY NAME MATCHING (Existing)
    # ---------------------------------------------------------
    # 4. Universal Strict Fuzzy Matching (nC2)
    for i in range(n):
        rec1 = records[i]
        for j in range(i + 1, n):
            rec2 = records[j]

            # Similarity Score
            similarity = fuzz.ratio(rec1["clean"], rec2["clean"])

            # Global Threshold (Ignore < 90%)
            if similarity < 90:
                continue

            # First Name Strict Filter
            # If first names differ, ignore unless similarity >= 97%
            if rec1["first"] != rec2["first"]:
                if similarity < 97:
                    continue

            # Calculate Edit Distance
            edit_dist = distance.Levenshtein.distance(rec1["clean"], rec2["clean"])

            # Risk Classification
            pattern = None
            risk = "LOW"

            # SPELLING_MANIPULATION (HIGH)
            # First name same, Last name same, Edit distance <= 1
            if (rec1["first"] == rec2["first"] and 
                rec1["last"] == rec2["last"] and 
                edit_dist <= 1):
                pattern = "SPELLING_MANIPULATION"
                risk = "HIGH"
            
            # FUZZY_HIGH (HIGH)
            elif similarity >= 94:
                pattern = "FUZZY_HIGH"
                risk = "HIGH"
            
            # FUZZY_MEDIUM (MEDIUM)
            elif similarity >= 90:
                pattern = "FUZZY_MEDIUM"
                risk = "MEDIUM"

            if pattern:
                # Collect amounts for Benford Analysis
                local_amounts = []
                for r_idx in [rec1['id'], rec2['id']]:
                    for col in [salary_col, net_col, bonus_col, incentive_col]:
                        if col:
                            try:
                                val = pd.to_numeric(df.at[r_idx, col], errors='coerce')
                                if pd.notna(val) and val > 0:
                                    suspicious_amounts.append(val)
                                    local_amounts.append(val)
                            except: pass

                # Local Benford Analysis for this specific pair
                benford_deviation = 0.0
                if local_amounts:
                    benford_deviation = calculate_benford_deviation(pd.Series(local_amounts))

                if benford_deviation > 0.10:
                    pattern = "FUZZY_BENFORD_ANOMALY"
                    risk = "HIGH"
                    details = f"{rec1['raw']} & {rec2['raw']} | Score: {similarity}% | Benford salary anomaly detected"
                else:
                    details = f"{rec1['raw']} & {rec2['raw']} | Score: {similarity}%"

                issues.append({
                    # App Compatibility
                    "module": "Payroll",
                    "type": pattern,
                    "issue_type": pattern,
                    "details": details,
                    "risk": risk,
                    
                    # Structured Output
                    "record_1": rec1["raw"],
                    "record_2": rec2["raw"],
                    "pattern": pattern,
                    "confidence": similarity,
                    "benford_deviation": benford_deviation
                })

    # ---------------------------------------------------------
    # 📊 4️⃣ BENFORD'S LAW ANALYSIS (Suspicious Transactions)
    # ---------------------------------------------------------
    if suspicious_amounts:
        suspicious_series = pd.Series(suspicious_amounts)
        deviation = calculate_benford_deviation(suspicious_series)

        if deviation > 0.10:
            issues.append({
                "module": "Payroll",
                "pattern": "BENFORD_PAYROLL_ANALYSIS",
                "type": "BENFORD_ANOMALY",
                "issue_type": "BENFORD_ANOMALY",
                "risk": "HIGH",
                "records_analyzed": len(suspicious_amounts),
                "expected_probability_digit_1": 0.301,
                "observed_deviation": deviation,
                "details": "Benford law deviation detected in suspicious payroll transactions. Salary amounts show abnormal first digit distribution."
            })

    # Overall Risk
    overall_risk = "LOW"
    if any(i["risk"] == "HIGH" for i in issues):
        overall_risk = "HIGH"
    elif any(i["risk"] == "MEDIUM" for i in issues):
        overall_risk = "MEDIUM"

    return {
        "issues": issues,
        "count": len(issues),
        "risk": overall_risk
    }