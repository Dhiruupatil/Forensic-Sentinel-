import pandas as pd

def circular_check(file):
    print("DEBUG: Starting circular_check")
    # Re-implement reading to support custom normalization and robustness
    file.seek(0)
    if file.filename.lower().endswith(".csv"):
        df = pd.read_csv(file)
    else:
        df = pd.read_excel(file)

    print(f"DEBUG: Loaded {len(df)} rows")

    # 1. Normalize column headers: Lowercase, strip, replace _ and - with space
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(r"[-_]", " ", regex=True)
        .str.replace(r"\s+", " ", regex=True) # Remove extra spaces
    )
    print(f"DEBUG: Columns detected: {df.columns.tolist()}")

    # 2. Detect columns automatically using alias matching
    # Item Unique ID
    item_col = next((c for c in df.columns if "unique" in c and "id" in c), None)
    if not item_col:
        item_col = next((c for c in df.columns if "item" in c and "id" in c), None)
    if not item_col:
        item_col = next((c for c in df.columns if "product" in c and "id" in c), None)
    
    # Purchase Date
    buy_col = next((c for c in df.columns if "purchase" in c and "date" in c), None)
    if not buy_col:
        buy_col = next((c for c in df.columns if "buy" in c and "date" in c), None)
    
    # Sales Date
    sell_col = next((c for c in df.columns if ("sales" in c or "sold" in c) and "date" in c), None)
    if not sell_col:
        sell_col = next((c for c in df.columns if "sale" in c and "date" in c), None)

    # Unit Price
    price_col = next((c for c in df.columns if "price" in c or "amount" in c or "rate" in c), None)

    print(f"DEBUG: Mapped Columns -> ID: {item_col}, Buy: {buy_col}, Sell: {sell_col}, Price: {price_col}")

    # Handle missing columns safely
    if not all([item_col, buy_col, sell_col]):
        return {
            "issues": [],
            "count": 0,
            "risk": "LOW",
            "error": "Missing Required Columns: Item Unique ID, Purchase Date, Sales Date"
        }

    # 3. Convert dates safely
    df[buy_col] = pd.to_datetime(df[buy_col], errors="coerce")
    df[sell_col] = pd.to_datetime(df[sell_col], errors="coerce")

    # Convert Price
    if price_col:
        df[price_col] = pd.to_numeric(df[price_col].astype(str).str.replace(r"[^0-9.]", "", regex=True), errors="coerce")

    issues = []

    # 4. Fraud Logic: Circular Trading (Repeated trading of same Unique ID)
    # Filter out rows where ID is missing
    df_clean = df.dropna(subset=[item_col])

    # Group by Item Unique ID
    grouped = df_clean.groupby(item_col)

    for item_id, group in grouped:
        count = len(group)
        if count >= 2:
            group = group.sort_values(by=buy_col)
            
            # Check Time Gaps (Short period rotation)
            group['days_diff'] = group[buy_col].diff().dt.days
            short_gap = (group['days_diff'] <= 10).any()
            
            if short_gap:
                if count > 2:
                    risk_type = "HIGH – Repeated Circular Rotation"
                    risk_level = "HIGH"
                else:
                    risk_type = "MEDIUM – Possible Rotation"
                    risk_level = "MEDIUM"

                dates = [d.strftime('%Y-%m-%d') for d in group[buy_col].dropna()]
                issues.append({
                    "row": str(group.index.tolist()),
                    "type": risk_type,
                    "details": f"Item ID: {item_id} | Rotations: {count} | Dates: {', '.join(dates)}",
                    "risk": risk_level
                })

    print(f"DEBUG: Total Suspicious Cases Found: {len(issues)}")

    count = len(issues)
    # Determine overall file risk based on highest risk found
    if any(i['risk'] == 'HIGH' for i in issues):
        risk = "HIGH"
    elif any(i['risk'] == 'MEDIUM' for i in issues):
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return {"issues": issues, "count": count, "risk": risk}