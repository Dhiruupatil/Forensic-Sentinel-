import pandas as pd

def normalize_columns(df):
    """
    Convert headers to:
    lowercase + remove spaces + remove _ and -
    Example: 'GST No' -> 'gstno'
    """
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "", regex=False)
        .str.replace("_", "", regex=False)
        .str.replace("-", "", regex=False)
    )
    return df

def read_file(file):
    """Read CSV or Excel safely + normalize headers"""
    if file.filename.endswith(".csv"):
        df = pd.read_csv(file)
    else:
        df = pd.read_excel(file)

    df = normalize_columns(df)
    return df