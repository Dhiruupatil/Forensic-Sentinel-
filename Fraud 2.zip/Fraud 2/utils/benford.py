import pandas as pd

def calculate_benford_deviation(series):
    """
    Calculates the deviation of the leading digit '1' from Benford's Law (30.1%).
    Returns the absolute deviation as a float (0.0 to 1.0).
    """
    # Convert to string, remove decimals to handle floats correctly
    series = series.astype(str).str.replace(r"[^0-9]", "", regex=True)
    # Extract first digit
    first_digits = series.str[0]
    # Filter for valid digits (1-9)
    first_digits = first_digits[first_digits.str.isnumeric() & (first_digits != "0")]
    
    if len(first_digits) == 0:
        return 0.0

    dist = first_digits.value_counts(normalize=True)
    # Expected frequency for '1' is ~0.301
    return abs(dist.get("1", 0) - 0.301)

def benford_test(series):
    """
    Returns True if deviation of digit '1' > 0.1 (10%).
    Used by Inventory module.
    """
    return calculate_benford_deviation(series) > 0.1