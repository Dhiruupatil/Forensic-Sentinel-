def find_column(df, possible_names):
    """
    Finds column even if name slightly different
    """
    for col in df.columns:
        for name in possible_names:
            if name in col:
                return col
    return None