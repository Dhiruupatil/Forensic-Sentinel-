document.addEventListener("DOMContentLoaded", function () {
    const downloadBtn = document.getElementById("btn-download-pdf");
    const overlay = document.getElementById("loading-overlay");

    if (downloadBtn && overlay) {
        downloadBtn.addEventListener("click", function (e) {
            e.preventDefault(); // Stop default link navigation temporarily

            // 1. Show Overlay
            overlay.classList.add("active");

            // 2. Disable Button
            downloadBtn.style.pointerEvents = "none";
            downloadBtn.style.opacity = "0.7";

            // 3. Trigger Download
            window.location.href = "/download-pdf";

            // 4. Hide Overlay after delay (3 seconds)
            // This gives enough time for the browser to start the download stream
            setTimeout(() => {
                overlay.classList.remove("active");
                downloadBtn.style.pointerEvents = "auto";
                downloadBtn.style.opacity = "1";
            }, 3000);
        });
    }
});