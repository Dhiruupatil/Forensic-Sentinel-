import pandas as pd
from functools import wraps
from flask import Flask, request, send_file, jsonify, render_template, redirect, url_for, session
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER
import datetime
import io
from modules.payroll import payroll_check
from modules.inventory import inventory_check
from modules.circular import circular_check

app = Flask(__name__)
app.secret_key = "forensic_sentinel_secret_key_2026"  # Required for sessions
SECRET_PASSKEY = "swami"  # Set your secure passkey here

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin@123"

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            if request.is_json or request.path.startswith("/api/"):
                return jsonify({"error": "Unauthorized", "status": "fail"}), 401
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.is_json:
            data = request.get_json() or {}
            username = data.get("username")
            password = data.get("password")
        else:
            username = request.form.get("username")
            password = request.form.get("password")

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["logged_in"] = True
            session["username"] = username
            if request.is_json:
                return jsonify({"status": "success", "redirect": "/"})
            return redirect(url_for("index"))
        else:
            if request.is_json:
                return jsonify({"status": "fail", "message": "Invalid username or password"}), 401
            return redirect(url_for("login", error="invalid"))

    if session.get("logged_in"):
        return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    return send_file("templates/index.html")

@app.route("/api/analyze", methods=["POST"])
@login_required
def analyze():
    payroll_file = request.files.get("payroll")
    inventory_file = request.files.get("inventory")
    circular_file = request.files.get("circular")

    payroll = payroll_check(payroll_file) if payroll_file and payroll_file.filename else {"risk": "LOW", "count": 0, "issues": []}
    inventory = inventory_check(inventory_file) if inventory_file and inventory_file.filename else {"risk": "LOW", "count": 0, "issues": [], "stats": {"valid": 0, "invalid": 0}}
    circular = circular_check(circular_file) if circular_file and circular_file.filename else {"risk": "LOW", "count": 0, "issues": []}

    # --- Generate Report CSV ---
    all_issues = []

    # Helper to collect issues
    def collect_issues(source, module):
        if source and "issues" in source:
            for issue in source["issues"]:
                issue_copy = issue.copy()
                issue_copy["Module"] = module
                all_issues.append(issue_copy)

    collect_issues(payroll, "Payroll")
    collect_issues(inventory, "Inventory")
    collect_issues(circular, "Circular Trading")

    # Save to CSV
    if all_issues:
        df = pd.DataFrame(all_issues)
        # Reorder columns for clarity if they exist
        cols = [c for c in ["Module", "type", "risk", "details", "row"] if c in df.columns]
        df = df[cols + [c for c in df.columns if c not in cols]]
        df.to_csv("fraud_report.csv", index=False)
    else:
        pd.DataFrame(columns=["Message"]).to_csv("fraud_report.csv", index=False)

    return jsonify({
        "payroll": payroll,
        "inventory": inventory,
        "circular": circular
    })

@app.route("/verify-key", methods=["POST"])
def verify_key():
    data = request.get_json()
    passkey = data.get("passkey")
    
    if passkey == SECRET_PASSKEY:
        return jsonify({"status": "success"})
    else:
        return jsonify({"status": "fail"})

@app.route("/download-report")
@login_required
def download_report():
    try:
        return send_file("fraud_report.csv", as_attachment=True, download_name="fraud_report.csv")
    except Exception as e:
        return f"Error downloading report: {str(e)}"

@app.route("/download-pdf")
@login_required
def download_pdf():
    try:
        # Read existing CSV report
        try:
            df = pd.read_csv("fraud_report.csv")
            # Fill NaN to avoid display issues
            df = df.fillna("")
        except FileNotFoundError:
            return "No analysis found. Please run an analysis first."

        # Calculate Summary Stats
        total_issues = len(df) if "risk" in df.columns else 0
        high_risk = len(df[df["risk"] == "HIGH"]) if "risk" in df.columns else 0
        medium_risk = len(df[df["risk"] == "MEDIUM"]) if "risk" in df.columns else 0
        low_risk = len(df[df["risk"] == "LOW"]) if "risk" in df.columns else 0
        
        # Create PDF Buffer
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        elements = []
        
        # Styles
        styles = getSampleStyleSheet()
        # Custom Styles
        title_style = ParagraphStyle('ReportTitle', parent=styles['Title'], fontSize=26, spaceAfter=10, alignment=TA_CENTER, textColor=colors.HexColor('#2c3e50'))
        subtitle_style = ParagraphStyle('ReportSubtitle', parent=styles['Heading2'], fontSize=16, spaceAfter=30, alignment=TA_CENTER, textColor=colors.HexColor('#7f8c8d'))
        header_style = ParagraphStyle('Header', parent=styles['Heading2'], fontSize=14, spaceAfter=10, textColor=colors.HexColor('#2c3e50'))
        normal_style = styles['Normal']

        # --- Cover Page ---
        elements.append(Spacer(1, 2 * inch))
        elements.append(Paragraph("Suspicious Transaction Report", title_style))
        elements.append(Paragraph("________________________________________", subtitle_style))
        elements.append(Spacer(1, 0.5 * inch))
        
        date_str = datetime.datetime.now().strftime('%B %d, %Y at %H:%M')
        elements.append(Paragraph(f"Generated on: {date_str}", ParagraphStyle('Date', parent=normal_style, alignment=TA_CENTER, fontSize=12)))
        
        elements.append(Spacer(1, 0.5 * inch))
        # Horizontal Line
        elements.append(Table([[""]], colWidths=[6*inch], style=[('LINEBELOW', (0,0), (-1,-1), 2, colors.HexColor('#34495e'))]))
        
        elements.append(PageBreak())

        # --- Executive Summary ---
        elements.append(Paragraph("Executive Summary", header_style))
        
        summary_data = [
            ["Metric", "Count"],
            ["Total Issues Detected", str(total_issues)],
            ["High Risk Incidents", str(high_risk)],
            ["Medium Risk Incidents", str(medium_risk)],
            ["Low Risk Incidents", str(low_risk)]
        ]
        
        summary_table = Table(summary_data, colWidths=[300, 100], hAlign='LEFT')
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (1, 0), colors.HexColor('#34495e')),
            ('TEXTCOLOR', (0, 0), (1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#ecf0f1')),
            ('GRID', (0, 0), (-1, -1), 1, colors.white),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#bdc3c7'))
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 0.5 * inch))

        # --- Detailed Anomalies ---
        elements.append(Paragraph("Detailed Anomalies", header_style))
        
        if "risk" in df.columns:
            # Table Header
            table_data = [["Module", "Issue Type", "Risk", "Details"]]
            
            # Table Styles List
            table_styles = [
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c3e50')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.lightgrey),
                ('LEFTPADDING', (0, 0), (-1, -1), 6),
                ('RIGHTPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]

            # Cell Text Style
            cell_style = ParagraphStyle('CellStyle', parent=normal_style, fontSize=9, leading=11)

            # Populate Data
            for i, row in enumerate(df.itertuples(), start=1):
                module = getattr(row, 'Module', 'N/A')
                issue_type = getattr(row, 'type', 'N/A')
                risk = getattr(row, 'risk', 'LOW')
                details = getattr(row, 'details', '')

                # Enhance details for Payroll Ghost Employees if fields exist
                if module == "Payroll" and issue_type == "GHOST_EMPLOYEE":
                    emp_name = getattr(row, 'employee_name', '')
                    emp_id = getattr(row, 'employee_id', '')
                    bank = getattr(row, 'bank_account', '')
                    salary = getattr(row, 'salary', '')
                    
                    extra_info = []
                    if emp_name: extra_info.append(f"<b>Employee Name:</b> {emp_name}")
                    if emp_id: extra_info.append(f"<b>Employee ID:</b> {emp_id}")
                    if bank: extra_info.append(f"<b>Bank Account:</b> {bank}")
                    if salary: extra_info.append(f"<b>Salary:</b> {salary}")
                    
                    if extra_info:
                        details = "<br/>".join(extra_info) + "<br/><b>Explanation:</b> " + details

                # Wrap text using Paragraph for columns that might overflow
                module_p = Paragraph(str(module), cell_style)
                type_p = Paragraph(str(issue_type), cell_style)
                detail_p = Paragraph(str(details), cell_style)
                
                table_data.append([module_p, type_p, risk, detail_p])

                # Conditional Formatting for Risk
                risk_color = colors.black
                if risk == "HIGH":
                    risk_color = colors.red
                elif risk == "MEDIUM":
                    risk_color = colors.orange
                elif risk == "LOW":
                    risk_color = colors.green
                
                table_styles.append(('TEXTCOLOR', (2, i), (2, i), risk_color))
                table_styles.append(('FONTNAME', (2, i), (2, i), 'Helvetica-Bold'))

            # Create Table
            issue_table = Table(table_data, colWidths=[70, 110, 50, 300], repeatRows=1)
            issue_table.setStyle(TableStyle(table_styles))
            elements.append(issue_table)
        else:
            elements.append(Paragraph("No fraud issues detected.", normal_style))

        # --- Footer Function ---
        def add_footer(canvas, doc):
            canvas.saveState()
            canvas.setFont('Helvetica', 9)
            canvas.setFillColor(colors.grey)
            page_num = canvas.getPageNumber()
            text = "Forensic Sentinel – Confidential Report"
            canvas.drawString(40, 30, text)
            canvas.drawRightString(letter[0] - 40, 30, f"Page {page_num}")
            canvas.restoreState()

        # Build PDF
        doc.build(elements, onFirstPage=add_footer, onLaterPages=add_footer)
        buffer.seek(0)
        
        return send_file(buffer, as_attachment=True, download_name="fraud_report.pdf", mimetype='application/pdf')

    except Exception as e:
        return f"Error generating PDF: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)